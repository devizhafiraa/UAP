package uap.interfaces;

public interface Konversi {
    double getKg();
    int getBiayaKirim();
}
