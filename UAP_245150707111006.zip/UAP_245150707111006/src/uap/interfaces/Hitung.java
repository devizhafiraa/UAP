package uap.interfaces;

public interface Hitung {
    double getVolume();
    double getLuasPermukaan();
    double getMassa();
}
